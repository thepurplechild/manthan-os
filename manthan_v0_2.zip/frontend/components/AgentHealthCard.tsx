"use client";
import { useEffect, useState } from "react";

export default function AgentHealthCard() {
  const [status, setStatus] = useState<null | { ok: boolean; frontend_origin: string }>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const url = `${process.env.NEXT_PUBLIC_BACKEND_URL}/health/config`;
    fetch(url)
      .then(r => r.json())
      .then(setStatus)
      .catch(e => setErr(e?.message || "Cannot reach backend"));
  }, []);

  return (
    <div className="rounded-2xl p-4 shadow bg-white space-y-2">
      <h3 className="text-lg font-semibold">Agent Health</h3>
      {err && <div className="text-red-600">{err}</div>}
      {status && (
        <div className="text-sm">
          <div>Backend reachable: <b>{status.ok ? "Yes" : "No"}</b></div>
          <div>Backend CORS expects: <code>{status.frontend_origin}</code></div>
        </div>
      )}
      {!status && !err && <div className="text-sm text-gray-500">Checking…</div>}
    </div>
  );
}
