# Manthan Creator Suite — v0.2 Drop-in

This package contains **added/updated files** to layer an agentic Creator Suite flow and CI checks on top of your existing repo (`v0.1`).

## What’s inside
- **GitHub Actions**: `.github/workflows/agent-ci.yml` (Repo Auditor + Config Doctor)
- **Backend (FastAPI)**:
  - `backend/app/main.py` with CORS and `/api/pitch/generate` + `/health/config`
  - `backend/requirements.txt`
  - `backend/Dockerfile`
- **Cloud Build**:
  - `infra/cloudbuild-backend.yaml`
  - `infra/cloudbuild-frontend.yaml`
- **Frontend**:
  - `frontend/lib/agents.ts`
  - `frontend/components/AgentButton.tsx`
  - `frontend/components/AgentHealthCard.tsx`
  - `frontend/app/page.tsx` (sample landing wired to the agent)
  - `frontend/next.config.ts` (safe default)

## How to apply (no terminal)
1. Upload/merge these files into the same paths in your GitHub repo (web UI is fine).
2. In **Cloud Run → manthan-frontend → Variables**, set:
   - `NEXT_PUBLIC_BACKEND_URL = https://<manthan-backend-...>.a.run.app`
3. (Optional) In **Cloud Run → manthan-backend → Variables**, set:
   - `FRONTEND_ORIGIN = https://<manthan-frontend-...>.a.run.app`
4. Push any change to `main`. **Actions → Agent CI** should pass. Cloud Build should redeploy both services.
5. Open your frontend URL; the **Agent Health** card should show “Backend reachable: Yes”. Click **Generate Pitch Pack**.

## Clean up / safe removals
If your previous backend contained duplicate routes or a different framework, keep only **one** server (this FastAPI app) to avoid port conflicts. If you already have `infra/cloudbuild-*.yaml`, prefer the ones in this drop (they standardize deploy flags).

> Later, when you bring in Google Sign-In (Identity Platform), add your Cloud Run frontend domain to **Authorized domains** to avoid `auth/network-request-failed` and keep everything HTTPS.

