from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os

app = FastAPI(title="Manthan Creator Suite Backend")

# CORS: Strict when FRONTEND_ORIGIN is set, permissive during early testing
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN")
origins = ["*"] if not FRONTEND_ORIGIN else [FRONTEND_ORIGIN]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class IdeaInput(BaseModel):
    title: str
    logline: str
    genre: str | None = None
    tone: str | None = None

class PitchPack(BaseModel):
    outline: list[str]
    one_pager: str
    deck_outline: list[str]

@app.post("/api/pitch/generate", response_model=PitchPack)
def generate_pitch(inp: IdeaInput):
    # v0 scaffold; swap for GPT later
    outline = [
      f"Act 1 — Inciting incident tied to: {inp.logline}",
      "Act 2 — Reversals & midpoint dilemma",
      "Act 3 — Climax & resolution with emotional payoff",
    ]
    one_pager = (
      f"Title: {inp.title}\n\nLogline: {inp.logline}\n\n"
      "Summary: In a world that mirrors contemporary India, our protagonist faces a choice "
      "between duty and desire, escalating through culturally grounded stakes."
    )
    deck = ["Cover", "Logline", "Synopsis", "Characters", "World", "Season Arc", "Why now?"]
    return PitchPack(outline=outline, one_pager=one_pager, deck_outline=deck)

@app.get("/health/config")
def config_health():
    return {"ok": True, "frontend_origin": FRONTEND_ORIGIN or "*"}
