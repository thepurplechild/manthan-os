import os, sys

REQUIRED = [
  "frontend/next.config.ts",
  "frontend/app/page.tsx",
  "backend/app/main.py",
  "infra/cloudbuild-backend.yaml",
  "infra/cloudbuild-frontend.yaml",
]

missing = [p for p in REQUIRED if not os.path.exists(p)]
if missing:
    print("❌ Repo Auditor failed.\nMissing files:\n - " + "\n - ".join(missing))
    print("\nFix: ensure your folder structure is exactly as above when uploading via GitHub web.")
    sys.exit(1)

print("✅ Repo Auditor passed.")
