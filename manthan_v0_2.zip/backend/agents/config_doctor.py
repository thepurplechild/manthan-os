import os, sys, textwrap

errors = []
warnings = []

# Frontend -> Backend URL
dotenv = "frontend/.env.local"
backend_url = None
if os.path.exists(dotenv):
    for line in open(dotenv, encoding="utf-8"):
        if line.startswith("NEXT_PUBLIC_BACKEND_URL="):
            backend_url = line.strip().split("=",1)[1]

if not backend_url:
    warnings.append("NEXT_PUBLIC_BACKEND_URL not found in frontend/.env.local (ok if set in Cloud Run env).")

# Backend CORS
main_py = "backend/app/main.py"
if os.path.exists(main_py):
    with open(main_py, "r", encoding="utf-8") as f:
        src = f.read()
    if "CORSMiddleware" not in src:
        errors.append("backend/app/main.py missing CORSMiddleware; add allowed origins incl. your Cloud Run frontend URL.")
else:
    errors.append("backend/app/main.py missing.")

# Cloud Build files
for f in ("infra/cloudbuild-backend.yaml","infra/cloudbuild-frontend.yaml"):
    if not os.path.exists(f):
        errors.append(f"Missing {f}. Your Cloud Build triggers will fail.")

if errors:
    print("❌ Config Doctor found issues:\n- " + "\n- ".join(errors))
    print(textwrap.dedent("""    Quick GUI fixes:
      1) Cloud Run → manthan-frontend → Variables:
           NEXT_PUBLIC_BACKEND_URL = https://<manthan-backend-...>.a.run.app
      2) Cloud Run → manthan-backend:
           Add CORS allow origin = your frontend URL (see FRONTEND_ORIGIN variable below).
      3) Firestore: ensure 'Native mode' in the same region as Cloud Run.
    """))
    sys.exit(1)

if warnings:
    print("⚠️  Warnings:\n- " + "\n- ".join(warnings))

print("✅ Config Doctor passed.")
